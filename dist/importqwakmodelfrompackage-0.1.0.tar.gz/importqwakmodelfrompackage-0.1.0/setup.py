# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['importqwakmodelfrompackage']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'importqwakmodelfrompackage',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Bartosz Mikulski',
    'author_email': 'mail@mikulskibartosz.name',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<3.11',
}


setup(**setup_kwargs)
